__version__ = '0.7.0a0+6631b74'
git_version = '6631b74db7cf8aebee8af196b4c65b1fce220baa'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
