This directory contains;

 - docker
   Docker image definition and scripts to build and update Docker image for unittest.
 - scripts
   Scripts used by CircleCI to run unit tests.
