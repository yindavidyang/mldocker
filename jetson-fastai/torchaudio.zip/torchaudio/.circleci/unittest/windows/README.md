This directory contains;

 - scripts
   Scripts used by CircleCI to run unit tests.
