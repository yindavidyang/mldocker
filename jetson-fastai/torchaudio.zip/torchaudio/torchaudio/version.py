__version__ = '0.6.0a0+d6f81d1'
git_version = 'd6f81d118e2ec116111c95d80e23566647645017'
