__version__ = '0.6.0a0+f17ae39'
git_version = 'f17ae39ff9da0df8f795fef2fcc192f298f81268'
